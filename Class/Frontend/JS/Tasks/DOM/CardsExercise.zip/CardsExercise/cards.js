console.log("Cards Task");

// variables
const inputTxt = document.getElementById("text");
const addBtn = document.getElementById("add");
const editBtn = document.getElementById("edit");
const removeBtn = document.getElementById("remove");
const usersList = document.getElementById("users-List");
let users = [];

// Functions
const addUser = () => {
	// Add a new user
	// @ts-ignore
	const user = inputTxt.value.trim();
	users.push(user);
	console.log(users);

	// Create/build new card elements
	const userCard = document.createElement("div");
	//const userCard = document.getElementById("card-title");
	userCard.classList.add("card-title");

	// @ts-ignore
	userCard.textContent = user;
	// @ts-ignore
	usersList.prepend(userCard);

	// Clear input text field
	// @ts-ignore
	inputTxt.innerHTML = "";
	// @ts-ignore
	inputTxt.value = "";

	removeBtn?.addEventListener("click", () => {
		userCard.remove();
	});
	// @ts-ignore
	editBtn.addEventListener("click", () => {
		// @ts-ignore
		userCard.textContent = inputTxt.value;
	});
};

// events
// @ts-ignore
addBtn.addEventListener("click", addUser);
